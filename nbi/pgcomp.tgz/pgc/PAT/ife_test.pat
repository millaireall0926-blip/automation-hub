
		SDEF	R	 C21		C17
		SDEF	W	 C19	
		SDEF	XCYC 	X<XC	Y<YC
		SDEF	XBYB 	X<XB	Y<YB

	REGISTER;
		IDX5 = 0x0F0F0F
		IDX6 = 0xA5A5A5
		S1A	= 0xFF
  ENDREGISTER
  		
START test
///////////////////////////////////////////////////////////////////////////////
// TEST
///////////////////////////////////////////////////////////////////////////////	
    NOP		
    NOP			
    NOP		
    NOP		             
    NOP
    NOP		             
    NOP	
    NOP	                   
    NOP	                   
A:	NOP	 W R    Z<0x01     
    NOP	 W R    Z<0x02     
    NOP	 W R    Z<0x03     
    NOP	 W R    Z<0x04 TS2    
    NOP	 W R    Z<0x05     
    NOP	 W R    Z<0x06   
    NOP	
    JSR FUNC1
    NOP	
    NOP	
    STI0 200	
    NOP
    NOP	
    LDI0 3	
    NOP	
    NOP
    NOP	                            TP1<0x00  TP2<0x00
    NOP	X<0x000000 Y<0x0000000      TP1<0x00  TP2<0x00 
    NOP	X<0x000001 Y<0x0000000      TP1<0x00  TP2<0x00
    NOP	X<0x000000 Y<0x0000001      TP1<0x00  TP2<0x00 
    NOP	X<0x000001 Y<0x0000001      TP1<0x00  TP2<0x00
    NOP	X<0x000000 Y<0x0000000      TP1<0x00  TP2<0x00 
    NOP	X<0x000001 Y<0x0000000      TP1<0x00  TP2<0x00
    NOP	X<0x000000 Y<0x0000001      TP1<0x00  TP2<0x00 
    NOP	X<0x000001 Y<0x0000001      TP1<0x00  TP2<0x00
    NOP	
    NOP	
    NOP
    NOP	
    NOP	
    NOP
END

FUNCTION FUNC1
    NOP
    NOP
    NOP
    RTN
ENDFUNCTION