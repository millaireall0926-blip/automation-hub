#pragma once

#define LIB_NAME	"Pattern Generate Common Library"
#define LIB_VER		"0.00.01"
#define LIB_DATE	"2021/06/18"
#define LIB_AUTHOR	"sypark"
#define LIB_DESC	LIB_NAME " " LIB_VER " " LIB_DATE " by " LIB_AUTHOR

// version history macros
#define VH_START	static char g_version_info[] = "%File-Version:" LIB_VER "%"; static char g_version_history[] = "%File-History:\n" 
#define HEADER(x,y)	"\n" #x #y"\n"
#define L(x)		"\t" #x "\n"
#define VH_END		"%";
#define VH_STATIC	puts(g_version_info); puts(g_version_history);
#define VH_COMPILED "Compiled on " __DATE__ "\n"
// user applied version history information start here 

VH_START
VH_COMPILED

HEADER("0.00.01 2021/06/17 by ", LIB_AUTHOR )
L("Start development.")

VH_END


#undef VH_START 
#undef VH_COMPILED 
#undef HEADER 
#undef L 
#undef VH_END
