#pragma once

#include <bitset>
#include <map>
#include <unordered_map>
#include <vector>

#define byte  unsigned char
#define word  unsigned short
#define dword unsigned int
#define qword uint64_t

#ifdef __linux__
#define __int64 __int64_t
#endif

#define MAX_NAME_LENGTH 39

#define ENCODE(cmd,opt,val) ( ((uint64_t)cmd<<32) | ((uint64_t)opt<<16) | (val) )

//#define MAX_IO 48
//#define MAX_DR 96
//#define MAX_SCAN 32
//#define MAX_CH 176 

//#define MAX_DR 64
//#define MAX_IO 64
//#define MAX_SCAN 32
//#define MAX_CLK 16
//#define MAX_CH 176 

//int g_MAX_CH = 176;
//int g_MAX_DR = 64;
//int g_MAX_IO = 64;
//int g_MAX_SCAN = 32;
//int g_MAX_CLK  = 16;

union ITEM
{
	qword value;
	struct {
		dword bit : 16;
		dword opt : 16;
		dword cmd;
	};

	ITEM() : value(0) {}
	ITEM(qword val) { value = val; }
	ITEM(int cmd, int opt, int bit)
	{
		this->cmd = cmd;
		this->opt = opt;
		this->bit = bit;
	}
};

typedef std::vector<std::vector<ITEM>> grammar_tree;
typedef std::map<std::string, grammar_tree> grammar_collage;
typedef std::map < std::string, uint64_t > SyntaxMap;
typedef std::map < std::string, SyntaxMap > SyntaxMapList;

enum COMP_TYPE {
	COMMON = 1,
	MACHINE,
	CHANNEL,
	BIB,
};

namespace BIBCOMP {
	enum {
		IOMODE = 1,
		SIZE,
		MAXSCAN,
		DUTTYPE,
		TDUT,
		DUT,
		UNKNOWN = 0xFF,
	};

	enum {
		DDR3 = 0,
		DDR4,
		DDR5,
		NAND = 16
	};
}

enum KEY_TYPE {
	KEY_NULL = 0,
	KEY_STR = 1, // �Ϲ� ���� IDX0 ...
	KEY_INT = 2, // 10���� 
	KEY_XINT = 4, // 16���� 0x1F
	KEY_FLT = 8, // �ε��Ҽ� 1.23 ...
	KEY_ASSIGN = 0xF, // =
	KEY_SYM = 0x10, // Ư������ +,-,~,[,],',' ...

	KEY_INV = 0x20,
	KEY_INC = 0x30,
	KEY_DEC = 0x40,
	KEY_ADD = 0x80,
	KEY_SUB = 0x90,

};

namespace KOBM //Kind of BM Command
{
	enum {
		C_EXIT = 1,
		C_ASSIGN,
		C_MACHINE_TYPE, //////////////////////////////
		C_CHANNEL_GROUP,/////     BM Compiler    /////
		C_BIB,			/////                    /////
		C_END,			//////////////////////////////
		C_TYPE,
		C_TYPE_NAME,
		C_DR_PIN,       
		C_IO_PIN,
		C_SCAN_PIN,
		C_CLK_PIN,
		C_PRE_DEF,
		C_GROUP_NAME,
		C_ROUND_LEFT,
		C_ROUND_RIGHT,
		C_BRACKET_LEFT,
		C_BRACKET_RIGHT,
		C_SQARE_LEFT,
		C_SQARE_RIGHT,
		C_OP_ADD,
		C_OP_SUB,
		C_OP_RANGE,
		C_DR_ARRAY,
		C_IO_ARRAY,
		C_SCAN_ARRAY,
		C_CLK_ARRAY,
		C_UNKNOWN,
		C_NUM,
		C_IOMODE,
		C_BIB_SIZE,
		C_MAX_SCAN,
		C_DUT_TYPE,
		C_DUT_ASSIGN, // "TDUT ="
		C_DUT_DEFINE, // "DUT 1 = "
		C_IO_SIZE,
		C_DUT_TYPE_INDEX,
		C_COMMA,
		C_SCAN_INDEX,
		//C_PREV_CH,
		//C_USER_CH,
	};
}

//namespace KOOP //Kind of Operator
//{
//	enum {
//		C_EXIT = 1,
//		C_XOR,
//		C_OR,
//		C_AND,
//	};
//}

//namespace OPSEL // operator select
//{
//	enum {
//		XOR = 1,
//		OR,
//		AND,
//		NOT,
//	};
//}

namespace CHCOMP
{
	enum
	{
		PIN = 0,
		PINGROUP,
	};

	enum
	{
		DR = 0,
		IO,
		SCAN,
		CLK,
		UNKNOWN = 0xFF,
	};
}

typedef struct{
		unsigned short nDut;
		unsigned short nScan;
		std::bitset<224> assign_ch;
}bib_dut_info_t;

typedef union
{
	unsigned int data[8];
	struct
	{
		unsigned short equipment;
		unsigned short devicetype;
		unsigned int reserved[7];
	};
}machine_t;

typedef struct
{
	unsigned short ch;
	unsigned char zone;
	unsigned char type;
	//unsigned char name[MAX_NAME_LENGTH + 1];
} channel_info_t;
typedef std::vector< channel_info_t> channel_data;

typedef struct
{
	unsigned char kind;
	channel_data channel;
} channel_db_t;
//typedef std::vector<std::pair<std::string, channel_db_t>> channel_map;
typedef std::map<std::string, channel_db_t > channel_map;

typedef struct {
	char token[8];
	ITEM item;
	bool result;
}soda_t;

#pragma pack(push ,1)
#pragma pack ( pop )

typedef union version {
	unsigned int data;
	struct {
		unsigned int target_eqp : 8; //Ÿ�� ���
		unsigned int major : 8;
		unsigned int minor : 8;
		unsigned int build : 8;
	};
}version_t;

typedef union date {
	unsigned int data[2];
	struct {
		unsigned int year : 16;
		unsigned int month : 8;
		unsigned int day : 8;
		unsigned int hour : 8;
		unsigned int min : 8;
		unsigned int sec : 8;
		unsigned int rsved : 8; // reserved
	};
}date_t;

typedef union fileheader
{
	unsigned int data[8];
	struct {
		version_t sw_v;  // 4byte
		version_t hw_v;  // 4byte
		date_t    date;  // 8byte
		unsigned int total_size;
		unsigned int head_size;
		unsigned int ch_size;
		unsigned int bib_size;
		
	};
}fileheader_t;