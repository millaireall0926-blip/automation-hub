#pragma once

#include <bitset>
#include <map>

#define byte  unsigned char
#define word  unsigned short
#define dword unsigned int
#define qword uint64_t

#ifdef __linux__
#define __int64 __int64_t
#endif

#define MAX_NAME_LENGTH 39

#define ENCODE(cmd,opt,val) ( ((uint64_t)cmd<<32) | ((uint64_t)opt<<16) | (val) )

union ITEM
{
	qword value;
	struct {
		dword bit : 16;
		dword opt : 16;
		dword cmd;
	};

	ITEM() : value(0) {}
	ITEM(qword val) { value = val; }
	ITEM(int cmd, int opt, int bit)
	{
		this->cmd = cmd;
		this->opt = opt;
		this->bit = bit;
	}
};

typedef std::vector<std::vector<ITEM>> grammar_tree;
typedef std::map<std::string, grammar_tree> grammar_collage;
typedef std::map < std::string, uint64_t > SyntaxMap;

enum SCR_TYPE {
	ADDR = 0,
	MEM = 1,
	DATA = 2,
};

enum COMP_TYPE {
	COMMON = 1,
	ADDR_SCR,
};

//enum LOG_TYPE {
//	MESSAGE = 1,
//	NOTICE,
//	WARNING,
//	ERROR,
//};

enum KEY_TYPE {
	KEY_NULL = 0,
	KEY_STR  = 1, // �Ϲ� ���� IDX0 ...
	KEY_INT  = 2, // 10���� 
	KEY_XINT = 4, // 16���� 0x1F
	KEY_FLT  = 8, // �ε��Ҽ� 1.23 ...
	KEY_SYM  = 0x10, // Ư������ =,# ...

	KEY_INV = 0x20,
	KEY_INC = 0x30,
	KEY_DEC = 0x40,
	KEY_ADD = 0x80,
	KEY_SUB = 0x90,

};

namespace KOSC //Kind of SCR Command
{
	enum {
		C_EXIT = 1,
		C_ADDR_SCRAM,
		C_END_SCRAM,
		C_DEST,
		C_ASSIGN,
		//C_INV,
		C_OPRN,
		C_ROUND_LEFT,
		C_ROUND_RIGHT,
		C_BRACKET_LEFT,
		C_BRACKET_RIGHT,
		C_OP_INFIX,
		C_OP_UNARY
	};
}

namespace KOOP //Kind of Operator
{
	enum {
		C_EXIT = 1,
		C_XOR,
		C_OR,
		C_AND,
	};
}

//namespace OPT //Option Command
//{
//	enum {
//		O_UINT = 1,
//		O_INT,
//		O_DOUBLE,
//	};
//}

namespace OPSEL // operator select
{
	enum {
		XOR = 1,
		OR,
		AND,
		NOT,
		 
		//XOR = 4,
		//OR,
		//AND,
		//XOR_XOR = 7,
		//OR_XOR,
		//AND_XOR,
		//XOR_OR,
		//OR_OR,
		//AND_OR,
		//XOR_AND,
		//OR_AND,
		//AND_AND,
		//
		//XOR_XOR_XOR,
		//OR_XOR_XOR,
		//AND_XOR_XOR,
		//XOR_OR_XOR,
		//OR_OR_XOR,
		//AND_OR_XOR,
		//XOR_AND_XOR,
		//OR_AND_XOR,
		//AND_AND_XOR,
		//
		//XOR_XOR_OR,
		//OR_XOR_OR,
		//AND_XOR_OR,
		//XOR_OR_OR,
		//OR_OR_OR,
		//AND_OR_OR,
		//XOR_AND_OR,
		//OR_AND_OR,
		//AND_AND_OR,
		//
		//XOR_XOR_AND,
		//OR_XOR_AND,
		//AND_XOR_AND,
		//XOR_OR_AND,
		//OR_OR_AND,
		//AND_OR_AND,
		//XOR_AND_AND,
		//OR_AND_AND,
		//AND_AND_AND,
	};
}

namespace ADDR_DEST {
	enum {
		X0 = 0,
		X1,
		X2,
		X3,
		X4,
		X5,
		X6,
		X7,
		X8,
		X9,
		X10,
		X11,
		X12,
		X13,
		X14,
		X15,
		X16,
		X17,
		X18,
		X19,
		X20,
		X21,
		X22,
		X23,

		//Y0 = 0x4000,
		Y0,
		Y1,
		Y2,
		Y3,
		Y4,
		Y5,
		Y6,
		Y7,
		Y8,
		Y9,
		Y10,
		Y11,
		Y12,
		Y13,
		Y14,
		Y15,
		Y16,
		Y17,
		Y18,
		Y19,
		Y20,
		Y21,
		Y22,
		Y23,

		//D0 = 0x8000,
		D0,
		D1,
		D2,
		D3,
		D4,
		D5,
		D6,
		D7,
		D8,
		D9,
		D10,
		D11,
		D12,
		D13,
		D14,
		D15,
		D16,
		D17,
	};
}

namespace ADDR_OPRN {
	enum {
		AX0 = 1,
		AX1,
		AX2,
		AX3,
		AX4,
		AX5,
		AX6,
		AX7,
		AX8,
		AX9,
		AX10,
		AX11,
		AX12,
		AX13,
		AX14,
		AX15,
		AX16,
		AX17,
		AX18,
		AX19,
		AX20,
		AX21,
		AX22,
		AX23,
		AY0 = 25,
		AY1,
		AY2,
		AY3,
		AY4,
		AY5,
		AY6,
		AY7,
		AY8,
		AY9,
		AY10,
		AY11,
		AY12,
		AY13,
		AY14,
		AY15,
		AY16,
		AY17,
		AY18,
		AY19,
		AY20,
		AY21,
		AY22,
		AY23,
		Uuknown,
	};

}

typedef struct {
	char token[8];
	ITEM item;
	bool result;
}soda_t;

#pragma pack(push ,1)
#pragma pack ( pop )

typedef union version {
	unsigned int data;
	struct {
		unsigned int rsved : 8; // reserved
		unsigned int major : 8;
		unsigned int minor : 8;
		unsigned int build : 8;
	};
}version_t;

//typedef struct version {
//	unsigned int rsved : 8; // reserved
//	unsigned int major : 8;
//	unsigned int minor : 8;
//	unsigned int build : 8;
//}version_t;

typedef union scr_data
{
	unsigned int data;
	struct {
		unsigned int _4th : 6;
		unsigned int _3rd : 6;
		unsigned int _2nd : 6;
		unsigned int _1st : 6;

		unsigned int op1 : 2;
		unsigned int op2 : 2;
		unsigned int op3 : 2;

		unsigned int reserved : 1;
		
		unsigned int inv : 1;
	};

}scr_data_t;

typedef union addr_scr_data
{
	scr_data_t data[24+24+18];
	struct {
		scr_data_t x_scr[24];
		scr_data_t y_scr[24];
		scr_data_t d_scr[18];
	};
}addr_scr_data_t;

typedef union scrinfo
{
	unsigned char data[48];
	struct {
		char name[MAX_NAME_LENGTH+1];
		unsigned int ntype : 8;
	};
}scrinfo_t;

typedef union date {
	unsigned int data[2];
	struct {
		unsigned int year : 16;
		unsigned int month : 8;
		unsigned int day : 8;
		unsigned int hour : 8;
		unsigned int min : 8;
		unsigned int sec : 8;
		unsigned int rsved : 8; // reserved
	};
}date_t;

typedef union fileheader
{
	unsigned int data[8];
	struct {
		version_t sw_v;  // 4byte
		version_t hw_v;  // 4byte
		date_t    date;  // 8byte
		unsigned int total_size;
		unsigned int head_size;
		unsigned int scr_size;
		unsigned int scr_count;
	};
}fileheader_t;